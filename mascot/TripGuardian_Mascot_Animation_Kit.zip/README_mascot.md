# TripGuardian Mascot — motion prototype

Created from the supplied original mascot image and guided by the supplied reference screen recording.

## Included
- `mascot_animated_demo.mp4` — six-second motion preview, 720×900, 24 fps, H.264.
- `mascot_idle.webp` — breathing/looking/blinking, transparent, looping.
- `mascot_greet.webp` — paw greeting/head gesture/blinks, transparent, looping.
- `mascot_thinking.webp` — inquisitive head tilt and paw shrug, transparent, looping.
- `mascot_web_demo.html` — interactive standalone browser showcase (open beside the WebP files).
- `TripGuardianMascot.tsx` — a React/Next.js component.
- `make_mascot.py` — editable animation prototype source. Uses the included original PNG and alpha mask.
- `mascot_preview.png` — preview thumbnail.

## Website integration
Put the three WebP files in `public/mascot/`, and copy `TripGuardianMascot.tsx` into your components folder:

```tsx
import TripGuardianMascot from './TripGuardianMascot';

<TripGuardianMascot mood="greet" width={320} />
```

`mood` accepts `idle`, `greet`, or `thinking`. SVG/GIF aren't necessary.

## Important scope note
This is an animated **2.5D image-based prototype**, not a real Blender 3D rig or GLB. Its soft local deformation preserves original photorealistic fur, hood, backpack and face. It does not provide true 360° rotation, articulated skeletal animation, or independently re-renderable geometry. Full 3D requires creating the mesh, grooming the fur, texturing and rigging with additional front/side/back reference views.

## Regenerate
Install `numpy opencv-python pillow scipy` and ensure FFmpeg is installed. Run `python make_mascot.py` in the folder with `image(20261016-041321).png` and `cut_mask.png`.
