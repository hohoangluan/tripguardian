'use client';

import { useState } from 'react';

type Mood = 'idle' | 'greet' | 'thinking';
interface Props {
  mood?: Mood;
  width?: number | string;
  className?: string;
  alt?: string;
  onClick?: () => void;
  assetsBase?: string;
}

/**
 * Copy mascot_*.webp into /public/mascot/ (or change assetsBase).
 * WebP loops contain animation and real transparency.
 * No WebGL or animation package is required.
 */
export default function TripGuardianMascot({
  mood = 'greet',
  width = 280,
  className = '',
  alt = 'Linh vật mèo du lịch TripGuardian',
  onClick,
  assetsBase = '/mascot',
}: Props) {
  const [hovered, setHovered] = useState(false);
  const canClick = typeof onClick === 'function';
  const style = {
    width,
    height: 'auto',
    display: 'block',
    cursor: canClick ? 'pointer' : 'default',
    filter: 'drop-shadow(0 15px 17px rgba(37,65,77,.16))',
    transform: hovered ? 'translateY(-5px) rotate(-1deg)' : 'translateY(0)',
    transition: 'transform 320ms cubic-bezier(.2,.8,.3,1)',
  } as const;
  return (
    <img
      src={`${assetsBase.replace(/\/$/, '')}/mascot_${mood}.webp`}
      alt={alt}
      className={className}
      style={style}
      role={canClick ? 'button' : undefined}
      tabIndex={canClick ? 0 : undefined}
      onClick={onClick}
      onKeyDown={canClick ? (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onClick(); } } : undefined}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      draggable={false}
    />
  );
}
