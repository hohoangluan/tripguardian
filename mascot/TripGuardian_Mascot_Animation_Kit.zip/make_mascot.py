"""TripGuardian mascot animation prototype (2.5D photo rig).
Uses only the supplied character artwork; produces transparent animated WebP and MP4.
Requirements: numpy, pillow, opencv-python, scipy, ffmpeg.
"""
from __future__ import annotations
import argparse, math, os, subprocess, time
import cv2, numpy as np
from PIL import Image

ROOT=os.path.dirname(os.path.abspath(__file__))
SOURCE=os.path.join(ROOT,'image(20261016-041321).png')
MASKFILE=os.path.join(ROOT,'cut_mask.png')
W,H=720,900
FPS=24
DUR=6.0
S=W/1122
Y,X=np.mgrid[0:H,0:W].astype(np.float32)
def smooth(x):
 x=np.clip(x,0,1); return x*x*(3-2*x)
def gaussian(t,c,s): return math.exp(-0.5*((t-c)/s)**2)
def envelope(t,a,b,c,d): return float(smooth((t-a)/(b-a))*(1-smooth((t-c)/(d-c))))
def g2(x,y,cx,cy,sx,sy): return np.exp(-0.5*((x-cx)/sx)**2 -0.5*((y-cy)/sy)**2).astype(np.float32)

im=cv2.imread(SOURCE, cv2.IMREAD_COLOR)
mask=cv2.imread(MASKFILE,cv2.IMREAD_GRAYSCALE)
if im is None or mask is None: raise RuntimeError('Source/matte not found')
mask=mask.copy()
# Reduce a few foreground-classified patches of the pale photographic backdrop.
for y0,y1,pairs in [
  (683,798,[(683,953),(718,926),(760,914),(798,965)]),
  (1034,1260,[(1034,950),(1080,924),(1140,888),(1200,841),(1260,777)]),
]:
 for yy in range(y0,min(mask.shape[0],y1)):
  right=np.interp(yy,[p[0] for p in pairs],[p[1] for p in pairs]); xx=np.arange(mask.shape[1]);
  # only eliminate far-right background; feather a narrow transition
  mask[yy,:]=np.minimum(mask[yy,:],np.clip((right-xx)*255/10+140,0,255).astype(np.uint8))
mask=cv2.resize(mask,(W,H),interpolation=cv2.INTER_AREA)
src=cv2.resize(im,(W,H),interpolation=cv2.INTER_AREA)
mask_f=mask.astype(np.float32)/255.0

# Blink replacement: reflect surrounding peach fur over the sclera and retain fine lid creases.
# This is held for ~120ms each time; original pupils return immediately afterwards.
closed=src.copy();paint=np.zeros((H,W),np.float32)
for cx,cy,rx,ry,slant in [(526,495,78,31,-6),(704,472,54,28,-7)]:
 cx,cy,rx,ry=[int(z*S) for z in (cx,cy,rx,ry)]
 ell=np.zeros((H,W),np.uint8)
 cv2.ellipse(ell,(cx,cy),(rx,ry),slant,0,360,255,-1)
 inner=cv2.erode(ell,np.ones((3,3),np.uint8),iterations=1)
 # paint natural fur into eyes from contiguous pixels
 inp=cv2.inpaint(closed,inner,14,cv2.INPAINT_TELEA)
 softness=cv2.GaussianBlur(ell,(0,0),4*S)/255.0
 closed=(inp.astype(np.float32)*softness[:,:,None]+closed.astype(np.float32)*(1-softness[:,:,None])).astype('uint8')
 paint=np.maximum(paint,softness)
 # retain fine sleepy eyelashes on fully closed lids
 ax=(int((cx/S-rx/S*.86)*S),int((cy/S+1)*S))
 bx=(int((cx/S+rx/S*.89)*S),int((cy/S-4)*S))
 cv2.line(closed,ax,bx,(87,133,177),max(1,int(2*S)),cv2.LINE_AA)
# pixel delta for fast blink morph
blink_delta=closed.astype(np.float32)-src.astype(np.float32)

# Nonrigid deformation rig, coordinates are normalized to final raster once.
hd_weight = (1-smooth((Y-430*S)/(420*S))) * smooth((X-90*S)/(150*S))*(1-smooth((X-943*S)/(155*S)))
paw_left=g2(X,Y,390*S,915*S,102*S,107*S)
paw_right=g2(X,Y,937*S,897*S,78*S,95*S)
scarf_weight=g2(X,Y,786*S,841*S,105*S,115*S)
ears_left=g2(X,Y,393*S,183*S,72*S,120*S)
ears_right=g2(X,Y,861*S,212*S,74*S,107*S)
breath_weight=g2(X,Y,589*S,1013*S,290*S,220*S)
# Original image has a little floor contact; move upwards when bobbing.

def make_frame(t:float,variant='greet'):
 phase=2*math.pi*t/DUR
 # All motions are periodic and settle back to the original pose before loop cut.
 bob=(-7*(1-math.cos(phase))/2)*S
 sway=(8*math.sin(phase))*S
 chest=(1.2*math.sin(phase-.4))*S
 theta=1.6*math.sin(phase)
 wave=0.0
 curiosity=0.0
 if variant=='greet':
  wave=envelope(t,0.65,1.05,2.45,3.02)
  curiosity=envelope(t,3.08,3.5,4.52,5.2)
 elif variant=='thinking':
  curiosity=envelope(t,0.65,1.4,4.2,5.5)
 elif variant=='idle':
  wave=0
 theta+=(4.3*curiosity - 2.1*wave)
 dx=np.zeros((H,W),np.float32)+sway
 dy=np.zeros((H,W),np.float32)+bob+chest*breath_weight
 # Light head turn / tilt, fixed around neck; scarf stays anchored to coat.
 rad=theta*math.pi/180
 dx += (-rad*(Y-663*S))*hd_weight
 dy += ( rad*(X-554*S))*hd_weight
 # Plush horn tips and furry hood spring gently with the head.
 dx += (3.3*S*math.sin(2*phase+.3))*ears_left+(2.6*S*math.sin(2*phase-1))*ears_right
 dy += (-2.3*S*math.sin(2*phase+.3))*ears_left + (2.5*S*math.sin(2*phase-1))*ears_right
 # Greeting wave: raise left mitten, then give it two small swings.
 dx += ( (-30 + 10*math.sin(13*t))*S*wave )*paw_left
 dy += ( (-76+8*math.sin(13*t+.4))*S*wave )*paw_left
 # Curiosity: visible blue mitten shifts slightly, mimicking a questioning shrug.
 dy += (-22*S*curiosity)*paw_right
 dx += (-11*S*curiosity)*paw_right
 # The scarf hangs behind the motion; delayed swing gives it secondary movement.
 dx += ((13*math.sin(phase-1.15)+6*wave*math.sin(12*t-1))*S)*scarf_weight
 dy += ( (6*math.sin(phase+.2)+4*wave)*S )*scarf_weight
 # Keep original facial expression except for natural, very short blinks.
 blink=max(gaussian(t,1.22,.085),gaussian(t,3.9,.093))
 if variant=='thinking': blink=max(gaussian(t,2.00,.095),gaussian(t,4.63,.085))
 if variant=='idle': blink=max(gaussian(t,2.35,.095),gaussian(t,4.75,.080))
 if blink>.008:
  blended=np.clip(src.astype(np.float32)+blink*blink_delta,0,255).astype('uint8')
 else:blended=src
 # Four-channel remap retains original fur details and produces alpha transparency.
 rgba=cv2.cvtColor(blended,cv2.COLOR_BGR2BGRA)
 rgba[:,:,3]=mask
 mx=X-dx; my=Y-dy
 moved=cv2.remap(rgba,mx,my,cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0,0))
 return moved,bob

# Warm clean studio background, cast a soft elliptical shadow, small foreground particles.
yratio=Y/H
bg=np.empty((H,W,3),np.uint8)
for k,(top,bot) in enumerate([(239,248),(223,236),(212,232)]):
 bg[:,:,k]=np.clip(top+(bot-top)*yratio+4*np.sin(np.pi*X/W),0,255).astype(np.uint8)
# BGR above: beige -> rose colored.
shadow_base=np.exp(-.5*((X-W*.50)/(W*.33))**2-.5*((Y-H*.89)/(H*.028))**2)
# big floor haze anchored to screen
rng=np.random.default_rng(24)
flakes=[(float(rng.uniform(0,W)),float(rng.uniform(0,H)),float(rng.uniform(1.3,3.1)),float(rng.uniform(.3,.9))) for _ in range(18)]

def composite(rgba,bob,t):
 back=bg.astype(np.float32).copy()
 shadow=(shadow_base*(.20 - .045*(-bob)/(8*S)))[:,:,None]
 back=back*(1-shadow)+np.array([163,164,164])[None,None,:]*shadow
 alpha=rgba[:,:,3:4].astype(np.float32)/255.
 out=rgba[:,:,:3].astype(np.float32)*alpha+back*(1-alpha)
 # faint drifting snowy sparkles for a cold Da Lat feel, behind the character
 for px,py,rad,speed in flakes:
  fx=int((px+8*math.sin(t+py/180))%W);fy=int((py+19*speed*t)%H)
  if alpha[fy,fx,0]>.05: continue
  if 0<=fy<H and 0<=fx<W:
   cv2.circle(out,(fx,fy),max(1,int(rad)),(255,250,250),-1,cv2.LINE_AA)
 return np.clip(out,0,255).astype('uint8')

def encode():
 video=os.path.join(ROOT,'mascot_animated_demo.mp4')
 proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','bgr24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',video],stdin=subprocess.PIPE)
 thumbs=[]
 for i in range(round(DUR*FPS)):
  t=i/FPS
  rgba,bob=make_frame(t,'greet')
  bgr=composite(rgba,bob,t)
  proc.stdin.write(bgr.tobytes())
  if i in (0,43,78,106): thumbs.append(bgr)
 proc.stdin.close();ret=proc.wait()
 if ret: raise RuntimeError('ffmpeg failed')
 print('Saved',video,os.path.getsize(video))
 # interactive website variants (transparent WebP, small and fast enough to deliver).
 for name in ('idle','greet','thinking'):
  arr=[]
  for i in range(0,round(DUR*FPS),2):
   t=i/FPS
   rgba,_=make_frame(t,name)
   tiny=cv2.resize(rgba,(480,600),interpolation=cv2.INTER_AREA)
   arr.append(Image.fromarray(cv2.cvtColor(tiny,cv2.COLOR_BGRA2RGBA),'RGBA'))
  path=os.path.join(ROOT,f'mascot_{name}.webp')
  arr[0].save(path,format='WEBP',save_all=True,append_images=arr[1:],duration=83,loop=0,lossless=False,quality=82,method=4)
  print('Saved',path,os.path.getsize(path))
 if thumbs:
  # User-facing preview poster from a genuine video frame.
  cv2.imwrite(os.path.join(ROOT,'mascot_preview.png'),thumbs[1])
if __name__=='__main__':encode()
